/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.frutimania.frutimania;

/**
 *
 * @author WI138
 */
public class Frutimania {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
